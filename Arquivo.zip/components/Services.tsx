import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Globe, Zap, Palette } from "lucide-react"

export default function Services() {
  return (
    <section id="services" className="w-full py-12 md:py-24 lg:py-32 bg-gray-100 dark:bg-gray-800 text-black">
      <div className="container mx-auto px-4 md:px-6">
        <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl text-center mb-12">Nossos Serviços</h2>
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader>
              <Globe className="w-8 h-8 mb-2" />
              <CardTitle>Design Responsivo</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>Sites que se adaptam perfeitamente a todos os dispositivos.</CardDescription>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <Zap className="w-8 h-8 mb-2" />
              <CardTitle>Otimização de Desempenho</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>Carregamento rápido e eficiente para melhor experiência do usuário.</CardDescription>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <Palette className="w-8 h-8 mb-2" />
              <CardTitle>Design Personalizado</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>Designs únicos que refletem a identidade da sua marca.</CardDescription>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}